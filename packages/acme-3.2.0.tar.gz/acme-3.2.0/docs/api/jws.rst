JWS
---

.. automodule:: acme.jws
   :members:
