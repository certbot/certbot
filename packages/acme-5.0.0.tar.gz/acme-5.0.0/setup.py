from setuptools import setup

version = '5.0.0'

setup(
    version=version,
)
