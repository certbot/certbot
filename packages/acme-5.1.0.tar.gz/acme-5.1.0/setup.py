from setuptools import setup

version = '5.1.0'

setup(
    version=version,
)
