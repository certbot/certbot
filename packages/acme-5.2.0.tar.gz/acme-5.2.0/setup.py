from setuptools import setup

version = '5.2.0'

setup(
    version=version,
)
