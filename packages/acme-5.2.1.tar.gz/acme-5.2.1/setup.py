from setuptools import setup

version = '5.2.1'

setup(
    version=version,
)
