from setuptools import setup

version = '5.2.2'

setup(
    version=version,
)
