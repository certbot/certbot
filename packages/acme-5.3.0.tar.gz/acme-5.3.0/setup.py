from setuptools import setup

version = '5.3.0'

setup(
    version=version,
)
