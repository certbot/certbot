from setuptools import setup

version = '5.3.1'

setup(
    version=version,
)
