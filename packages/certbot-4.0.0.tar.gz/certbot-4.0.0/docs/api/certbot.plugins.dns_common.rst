certbot.plugins.dns\_common module
==================================

.. automodule:: certbot.plugins.dns_common
    :members:
    :undoc-members:
    :show-inheritance:
