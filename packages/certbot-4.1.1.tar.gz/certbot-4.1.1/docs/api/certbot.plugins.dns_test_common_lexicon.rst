certbot.plugins.dns\_test\_common\_lexicon module
=================================================

.. automodule:: certbot.plugins.dns_test_common_lexicon
    :members:
    :undoc-members:
    :show-inheritance:
