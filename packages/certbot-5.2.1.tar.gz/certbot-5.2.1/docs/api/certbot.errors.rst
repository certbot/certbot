certbot.errors module
=====================

.. automodule:: certbot.errors
    :members:
    :undoc-members:
    :show-inheritance:
