certbot.plugins.dns\_common\_lexicon module
===========================================

.. automodule:: certbot.plugins.dns_common_lexicon
    :members:
    :undoc-members:
    :show-inheritance:
