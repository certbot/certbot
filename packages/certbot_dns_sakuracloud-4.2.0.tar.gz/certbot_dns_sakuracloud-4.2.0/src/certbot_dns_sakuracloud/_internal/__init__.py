"""Internal implementation of `~certbot_dns_sakuracloud.dns_sakuracloud` plugin."""
