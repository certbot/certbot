from setuptools import setup

version = '1.2.3'

install_requires = [
    # We specify the minimum certbot version as the current plugin
    # version for simplicity. See
    # https://github.com/certbot/certbot/issues/8761 for more info.
    f'certbot[nginx]>={version}',
]

setup(
    version=version,
    install_requires=install_requires,
)
